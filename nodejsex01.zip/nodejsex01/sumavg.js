exports.sumNum =function (x, y){
    return x + y;
}

exports.average =function (x, y){
    return (x + y)/2;
}